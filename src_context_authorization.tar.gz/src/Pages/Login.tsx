import React, {useContext, useState} from 'react';
import {LoginContext} from "../Helper/Context";


const Login = () => {
    const {loggedIn, setLoggedIn} = useContext(LoginContext)

    return (
        <div style={{border: "red 5px solid", color: "blue"}}>
            this is login page
            <button onClick={() => setLoggedIn(true )}>click to go login </button>
            {loggedIn ? <h1>you are logged In</h1> : <h1>you are nooooot logged In</h1>}
        </div>
    );
};

export default Login