import React, {createContext, useState} from "react";

type UserContextType = {
    loggedIn: boolean,
    setLoggedIn: React.Dispatch<React.SetStateAction<boolean>>
}

export const LoginContext = createContext<UserContextType>({loggedIn:false,setLoggedIn:()=>false})
export const ProviderContext = ({children}:{children:React.ReactNode}) => {
    const [loggedIn,setLoggedIn] = useState(false);
    return <LoginContext.Provider  value={{loggedIn , setLoggedIn }}>{children}</LoginContext.Provider>
}



