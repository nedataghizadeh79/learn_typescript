import React, {useState, useContext, createContext} from "react";
import Home from "./Pages/Home";
import Login from "./Pages/Login";
import Profile from "./Pages/Profile";

import {ProviderContext} from "./Helper/Context";

const App = () => {

    return (
        <ProviderContext >
            <Home/>
            <br/>
            <Login/>
            <br/>
            <Profile/>
        </ProviderContext>
    )
}

export default App


